package com.cindy.login;

public interface CallbackFragment {
    void changeFragment();
}
